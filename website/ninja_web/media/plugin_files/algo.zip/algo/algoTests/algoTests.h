//
//  algoTests.h
//  algoTests
//
//  Created by Pedro Mourelle on 13/10/11.
//  Copyright 2011 Pm DESIGN. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface algoTests : SenTestCase

@end
