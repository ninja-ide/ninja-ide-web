//
//  algoAppDelegate.h
//  algo
//
//  Created by Pedro Mourelle on 13/10/11.
//  Copyright 2011 Pm DESIGN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface algoAppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@end
