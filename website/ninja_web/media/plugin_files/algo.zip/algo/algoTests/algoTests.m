//
//  algoTests.m
//  algoTests
//
//  Created by Pedro Mourelle on 13/10/11.
//  Copyright 2011 Pm DESIGN. All rights reserved.
//

#import "algoTests.h"

@implementation algoTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in algoTests");
}

@end
