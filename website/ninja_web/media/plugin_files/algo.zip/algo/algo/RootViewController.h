//
//  RootViewController.h
//  algo
//
//  Created by Pedro Mourelle on 13/10/11.
//  Copyright 2011 Pm DESIGN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController

@end
